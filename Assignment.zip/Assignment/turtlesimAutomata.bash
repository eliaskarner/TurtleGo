#!/bin/bash

# Exit immediately on error
set -e

echo "=== STARTING TURTLESIM AUTOMATA INSTALLATION ==="

# Step 1: Create ROS 2 workspace
mkdir -p ~/ros2_ws/src

# Step 2: Remove any previous version of the package
if [ -d ~/ros2_ws/src/turtlesimAutomata ]; then
    echo "Removing existing turtlesimAutomata from workspace..."
    rm -rf ~/ros2_ws/src/turtlesimAutomata
fi

# Step 3: Move local package folder from Downloads/Assignment to workspace
if [ -d ~/Downloads/Assignment/turtlesimAutomata ]; then
    echo "Moving turtlesimAutomata into workspace..."
    mv ~/Downloads/Assignment/turtlesimAutomata ~/ros2_ws/src/
else
    echo "ERROR: ~/Downloads/Assignment/turtlesimAutomata not found!"
    exit 1
fi

# Step 4: Replace controller script, setup.py and package.xml from GitHub
echo "Fetching updated files from GitHub..."
curl -L -o ~/ros2_ws/src/turtlesimAutomata/setup.py https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/setup.py
curl -L -o ~/ros2_ws/src/turtlesimAutomata/package.xml https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/package.xml
curl -L -o ~/ros2_ws/src/turtlesimAutomata/turtlesimAutomata/turtle_controller.py https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/turtlesimAutomata/turtle_controller.py

# Step 5: Make the controller executable
chmod +x ~/ros2_ws/src/turtlesimAutomata/turtlesimAutomata/turtle_controller.py

# Step 6: Build the workspace
cd ~/ros2_ws
colcon build

# Step 7: Source the workspace
source install/setup.bash

# Step 8: Clean up the Assignment folder
if [ -d ~/Downloads/Assignment ]; then
    echo "Cleaning up ~/Downloads/Assignment..."
    rm -rf ~/Downloads/Assignment
fi

# Step 9: Launch turtlesim and controller
echo "Launching turtlesim and turtle_controller..."
ros2 launch turtlesimAutomata turtlesim_automata.launch.py

echo "=== TURTLESIM AUTOMATA SETUP COMPLETE ==="
