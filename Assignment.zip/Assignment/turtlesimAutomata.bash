#!/bin/bash

# Stop the script on any error
set -e

# Create the workspace and source directory
mkdir -p ~/ros2_ws/src

# Remove existing turtlesimAutomata package if it exists
if [ -d ~/ros2_ws/src/turtlesimAutomata ]; then
    echo "Removing existing turtlesimAutomata from workspace..."
    rm -rf ~/ros2_ws/src/turtlesimAutomata
fi

# Copy turtlesimAutomata from Downloads/Assignment to workspace
if [ -d ~/Downloads/Assignment/turtlesimAutomata ]; then
    echo "Copying turtlesimAutomata to workspace..."
    cp -r ~/Downloads/Assignment/turtlesimAutomata ~/ros2_ws/src/
else
    echo "ERROR: Cannot find ~/Downloads/Assignment/turtlesimAutomata"
    exit 1
fi

# Download the latest files from GitHub
echo "Updating files from GitHub..."
curl -L -o ~/ros2_ws/src/turtlesimAutomata/setup.py https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/setup.py
curl -L -o ~/ros2_ws/src/turtlesimAutomata/package.xml https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/package.xml

# Create folder if needed, then download turtle_controller.py
mkdir -p ~/ros2_ws/src/turtlesimAutomata/turtlesimAutomata
curl -L -o ~/ros2_ws/src/turtlesimAutomata/turtlesimAutomata/turtle_controller.py https://raw.githubusercontent.com/eliaskarner/TurtleGo/main/turtlesimAutomata/turtlesimAutomata/turtle_controller.py

# Make the controller executable
chmod +x ~/ros2_ws/src/turtlesimAutomata/turtlesimAutomata/turtle_controller.py

# Build the workspace
cd ~/ros2_ws
colcon build

# Source the workspace
source install/setup.bash

# Final instructions
echo ""
echo "===================================================================="
echo "Installation complete!"
echo ""
echo "Open a new terminal and run the following:"
echo ""
echo ""
echo "2. Terminal 2:"
echo "   source ~/ros2_ws/install/setup.bash"
echo "   ros2 run turtlesimAutomata turtle_controller"
echo ""
echo "===================================================================="


# Delete the Assignment folder from Downloads
echo "Cleaning up ~/Downloads/Assignment..."
rm -rf ~/Downloads/Assignment

# launch tirtlesim_node
#ros2 run turtlesim turtlesim_node

echo "Launching both turtlesim and turtle_controller nodes..."
ros2 launch turtlesimAutomata turtle_start.launch.py