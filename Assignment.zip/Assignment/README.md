# turtlesimAutomata Installation Script

This zip provides a bash script (`turtlesimAutomata.bash`) to automate the setup of the `turtlesimAutomata` ROS 2 Python package.
The logic of the code is mad up by myself and for the coding I sometimes used ChatGPT.


# What the Script Does

The `turtlesimAutomata.bash` script performs the following steps:

1. **Create Workspace**: Ensures that the `ros2_ws` workspace and `src` folder exist.
2. **Move Local Package**: Moves the `turtlesimAutomata` folder (assumed to be located in `~/Downloads/Assignment`) into the workspace.
3. **Update Source Files**: Fetches the latest `setup.py`, `package.xml`, and `turtle_controller.py` from GitHub.
4. **Set Executable Permissions**: Ensures the controller script is executable.
5. **Build and Source**: Builds the workspace with `colcon` and sources the environment.
6. **Launch turtlesim_node**: Starts the turtlesim GUI in the terminal.
7. **Display Instructions**: Prints instructions for how to start the controller node in a second terminal.
8. **Cleanup**: Deletes the `~/Downloads/Assignment` folder

# How to Use

1. Place the entire `Assignment` folder (including the bash script and `turtlesimAutomata` directory) into your `~/Downloads` folder.
2. Open a terminal and make the script executable:
   ```bash
   cd ~/Downloads/Assignment
   chmod +x turtlesimAutomata.bash
   ./turtlesimAutomata.bash
